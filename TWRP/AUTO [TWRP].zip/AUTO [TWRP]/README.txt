En caso de que el comando no funciona, ejecutar la siguiente linea de codigo en el archivo: "FLASH RECOVERY AUTO.bat"

fastboot boot twrp.img


In case the command does not work, execute the following line of code in the file: "FLASH RECOVERY AUTO.bat"

fastboot boot twrp.img